SIYODA ENTERPRISES — Modern Equipment Rental Website

Files:
- index.html: responsive bilingual website inspired by the layout in your screenshots, with search, equipment category cards, service areas, contact details, and WhatsApp inquiry form.

How to use:
1. Extract this ZIP file.
2. Upload index.html to your hosting or GitHub Pages repository.
3. The site is not automatically published by downloading this ZIP. Connect siyodaenterprises.com after publishing.

WhatsApp inquiries go to +94 777 320 311. Other contact: +94 71 316 1476.
Please review equipment list and images before launch. The equipment cards currently use decorative symbols; your own equipment photos can be added later for a more authentic look.
